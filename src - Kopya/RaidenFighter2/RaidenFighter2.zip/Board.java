package RaidenFighter2;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.MenuComponent;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

//The Board is a panel where the game takes place

public class Board extends JPanel implements ActionListener  {

	private int ICRAFT_X = 0;
	private int ICRAFT_Y = 0;
	
	private int boardWidth = 0;
	private int boardHeight = 0;
	
	
	private int PassTimeMS = 0;
	private int PassTimeSC = 0;
	private int PassTimeMN = 0;
	
	private Timer timer;
	private Craft craft;

	
	private final int DELAY = 17;
	
	
	JFrame mainFrame;
	
	ArrayList<Enemy> enemies = new ArrayList<Enemy>();
	Random rand = new Random();
	
	public Board(int width,int height,JFrame mainApp){
		
		
		this.mainFrame = mainApp;
		
		boardWidth = width;
		boardHeight = height;
		
	//	System.out.println(boardHeight);
		
		ICRAFT_X = this.boardWidth / 2 - 50  ;
		ICRAFT_Y = this.boardHeight - 200;
		
		
		initBoard();
	}
	
	private void initBoard(){
		addKeyListener(new TAdapter());
		
		
		setFocusable(true);

		
		setBackground(Color.BLACK);
	//	setLayout(new FlowLayout());	
		setDoubleBuffered(true);
		craft = new Craft(ICRAFT_X,ICRAFT_Y,this);
		Border border = LineBorder.createGrayLineBorder();

		craft.label.setBorder(border);
		craft.label.setSize(50,50);
		add(craft.getLabel());
		
		
		
		for(int i = 0 ; i < craft.getHealth().size() ; i ++) {
			
			add( craft.getHealth().get(i).getLabel()) ;
		}

		timer = new Timer(DELAY,this);
		timer.start();
		
		
		this.requestFocus ();
	}
	
	
	public void doDrawing(){
	
		
		
		
		craft.getLabel().setLocation(craft.getX(),craft.getY());
		
		
		ArrayList ms = craft.getMissiles();
		
		for(Object m1 : ms){
			Missile m = (Missile) m1;
			m.getLabel().setLocation(m.x, m.y);
			
			
		}
		
		int lifeCounter = craft.getLife();
		
		for(int i = 0 ; i < lifeCounter ; i ++) {
			
			
			craft.getHealth().get(i).getLabel().setLocation( ( i * 50 ) , this.boardHeight-175);
		}
		
		
		
		for(Object m1 : this.enemies){
			Enemy m = (Enemy) m1;
			m.getLabel().setLocation(m.x, m.y);
			
			
		}
		
	}
	
	
	

	@Override
	public void actionPerformed(ActionEvent arg0) {

		
		
		PassTimeMS++;
		
		if(this.PassTimeMS == 58){
		
			//System.out.println(PassTimeSC);
			PassTimeSC++;
			PassTimeMS = 0;
		}
		
		if(this.PassTimeSC == 60){
			PassTimeMN++;
		}
		
		
		
		updateMissiles();
		updateCraft();
		updateEnemy();
		
		
		checkCollisions();
		
		repaint();
		
		if(craft.isDead() == true){
			gameOver();
			mainFrame.remove(this);
			return;
		}
		
		doDrawing();
	}
	
	
	
	private class TAdapter extends KeyAdapter {
		
		@Override
		public void keyReleased(KeyEvent e){
			craft.keyReleased(e);
			
		}
		@Override
		public void keyPressed(KeyEvent e){
			craft.keyPressed(e);
		}
	}
	
	private void updateCraft(){
		
		craft.move();
	}
	
	
	private void updateMissiles(){
		ArrayList<Missile> ms = craft.getMissiles();
		
		
		
		
		for(int i = 0; i < ms.size(); i++){
			Missile m = (Missile) ms.get(i);
			
		
			
			if(m.isVisible()) {
				
				m.move();
			}
			else{
				ms.remove(i);
				this.remove(m.getLabel());
			}
		
		}
	}
	
	
	private void updateEnemy(){
		
		if( ( this.PassTimeSC  % 2 == 0 ) && ( this.PassTimeMS == 0 )   ){
			
			boolean valid = true;
			
			int n; 
			
			while(true){
				valid = true;
				n = rand.nextInt(this.boardWidth - 100 ) + 50;
			
				for( Enemy m : this.enemies){
					
					int x = m.x;
					
					if(Math.abs(n - x) < 50 ){
						valid = false;
					}
					
				}
				if(valid){
					break;
				}
			
			
			
			}
			Menu myMenuBar = (Menu) this.mainFrame.getJMenuBar();
			
			PlayerInfo myPlayer = myMenuBar.getMyPlayer();
			
			int random_enemy = 0;
			
			if(myPlayer.getLevel() == 0){
				 random_enemy = rand.nextInt(3)  + 1;
			}
			if(myPlayer.getLevel() == 1){
				 random_enemy = rand.nextInt(5)  + 1;
			}
			
			
			
			Enemy newEnemy = null;
			
			switch(random_enemy){

			case 1:
				 newEnemy = new Enemy_Beginner(n,0);
				 break;
			case 2:
				newEnemy = new Enemy_Easy(n,0);
				break;
			case 3:
				newEnemy = new Enemy_Medium(n,0);
				break;
			case 4:
				newEnemy = new Enemy_Hard(n,0);
				break;
			case 5:
				newEnemy = new Enemy_Tank(n,0);
				break;
			default:				
				System.out.println(random_enemy);
				break;
			}
			
			
			Border border = LineBorder.createGrayLineBorder();
			newEnemy.label.setBorder(border);
			newEnemy.label.setBounds(n,0,50,50);
			this.enemies.add(newEnemy);
			add(newEnemy.getLabel());
		
		
		}
		
		
		for(int i = 0; i < this.enemies.size(); i++){
			Enemy m = (Enemy) enemies.get(i);
			
		
			
			if(m.isVisible()) {
				
				m.move();
			}
			else{
				this.enemies.remove(i);
				this.remove(m.label);
			}
		
		}
		
		
		
		
		
		
	}
	
	public void checkCollisions(){
		Rectangle r3 = craft.getLabel().getBounds();
		
		for(Enemy enemy : this.enemies){
			Rectangle r2 = enemy.getLabel().getBounds();
			
			if(r3.intersects(r2)){
				
				craft.getDamage();
				
				this.remove(craft.getHealth().get(craft.getHealth().size() -1).label);
				craft.getHealth().remove(craft.getHealth().size() -1);
				
				enemy.setVisible(false);
			}
		}
		
		
		ArrayList<Missile> ms = craft.getMissiles();
		
		for(Missile m : ms){
			Rectangle r1 = m.getLabel().getBounds();
			
			for( Enemy enemy : this.enemies){
				Rectangle r2 = enemy.getLabel().getBounds();
				
				
				if(r1.intersects(r2)){
					craft.increaseScore(50);
					m.setVisible(false);
					enemy.setVisible(false);
				}
				
			}
			
			
			
		}
		
	}
	
	private void gameOver(){
		
		savePlayer();
		
		timer.stop();
		
		mainFrame.getContentPane().remove(this);
		mainFrame.validate();
		mainFrame.repaint();
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		
		int width = screenSize.width * 1 / 4;
		
		int height = screenSize.height / 16  * 9 ;
	
		Menu myMenu = (Menu) mainFrame.getJMenuBar();
		
		mainFrame.getContentPane().add(myMenu.gifLabel);
	
		mainFrame.revalidate();
		
		mainFrame.repaint();
		
		myMenu.requestFocusInWindow();
		
	}
	
	private void savePlayer(){
		
		Menu myMenu = (Menu) mainFrame.getJMenuBar();
		
		myMenu.savePlayer(craft.getLevel(), craft.getScore());
		
		
	}

}
