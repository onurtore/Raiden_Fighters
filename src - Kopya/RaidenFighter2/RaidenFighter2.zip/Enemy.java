package RaidenFighter2;

public class Enemy extends Sprite{

	private final int ENEMY_SPEED = 1;

	public Enemy(int x, int y) {
		super(x, y);

	}

	public void move(){
		y += ENEMY_SPEED;
		if(y > 1008){
			vis = false;
		}
	}
	
}
