package RaidenFighter2;

public class Enemy_Beginner extends Enemy{

	private final int ENEMY_SPEED = +1;
	
	public Enemy_Beginner(int x, int y) {
		super(x, y);

		initEnemy();
	}
	
	public void initEnemy(){

		loadLabel("enemy1.png");
		getLabelDimensions();
	}
	
	public void move(){
		y += ENEMY_SPEED;
		if(y > 1008){
			vis = false;
		}
	}

}
